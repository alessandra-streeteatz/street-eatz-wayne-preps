"""
Street Eatz — Vendor Store Backend
Flask + SQLite

Endpoints:
  GET    /api/vendor              → vendor profile
  PUT    /api/vendor              → update vendor profile
  GET    /api/vendor/status       → open/closed + hours
  PUT    /api/vendor/status       → toggle open/closed

  GET    /api/menu                → all menu items
  POST   /api/menu                → create menu item
  PUT    /api/menu/<id>           → update menu item
  DELETE /api/menu/<id>           → delete menu item

  POST   /api/orders              → place new order
  GET    /api/orders              → list all orders (vendor dashboard)
  GET    /api/orders/<id>         → single order
  PUT    /api/orders/<id>/status  → update order status

  POST   /api/checkout/initiate   → validate cart + return order summary
                                     (Stripe hook goes here when keys are added)

  GET    /api/uploads/<filename>  → serve uploaded photos
  POST   /api/uploads             → upload a photo
"""

import os, uuid, sqlite3, json
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, g

# ── Config ────────────────────────────────────────────────────────────────────

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DB_PATH     = os.path.join(BASE_DIR, "street_eatz.db")
UPLOAD_DIR  = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "webp"}
MAX_UPLOAD  = 10 * 1024 * 1024  # 10 MB

os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD

# ── CORS (inline, no external dep) ───────────────────────────────────────────

@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"]  = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    return resp

@app.route("/api/<path:p>", methods=["OPTIONS"])
def options_handler(p):
    return "", 204

# ── DB helpers ────────────────────────────────────────────────────────────────

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript("""
        CREATE TABLE IF NOT EXISTS vendor (
            id          INTEGER PRIMARY KEY CHECK (id = 1),
            name        TEXT    NOT NULL DEFAULT 'Wayne Preps',
            slug        TEXT    NOT NULL DEFAULT 'wayne-preps',
            instagram   TEXT    DEFAULT '@waynepreps',
            phone       TEXT    DEFAULT '(205) 555-0198',
            location    TEXT    DEFAULT 'Birmingham, AL',
            hours       TEXT    DEFAULT 'Mon–Sat  11AM – 7PM',
            payment_methods TEXT DEFAULT 'Cash · CashApp · Venmo',
            is_open     INTEGER NOT NULL DEFAULT 1,
            accent_color TEXT   DEFAULT '#ff6b00',
            theme       TEXT    DEFAULT 'orange',
            logo_url    TEXT    DEFAULT NULL,
            hero_url    TEXT    DEFAULT NULL,
            created_at  TEXT    DEFAULT (datetime('now')),
            updated_at  TEXT    DEFAULT (datetime('now'))
        );

        INSERT OR IGNORE INTO vendor (id) VALUES (1);

        CREATE TABLE IF NOT EXISTS menu_items (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            price       REAL    NOT NULL,
            description TEXT    DEFAULT '',
            category    TEXT    DEFAULT 'Meal Prep',
            tag         TEXT    DEFAULT NULL,
            photo_url   TEXT    DEFAULT NULL,
            is_available INTEGER NOT NULL DEFAULT 1,
            sort_order  INTEGER NOT NULL DEFAULT 0,
            created_at  TEXT    DEFAULT (datetime('now')),
            updated_at  TEXT    DEFAULT (datetime('now'))
        );

        INSERT OR IGNORE INTO menu_items (id, name, price, description, category, tag, sort_order) VALUES
          (1, 'Classic Meal Prep',     15, 'Your choice of protein with rice, veggies, or both. Seasoned fresh daily.',                'Meal Prep',   'Most Popular', 0),
          (2, 'Low Carb Prep',         12, 'Protein + veggies only. No rice, no heavy carbs. Clean, lean and satisfying.',             'Meal Prep',   'Low Carb',     1),
          (3, 'Steak Prep',            18, 'Premium steak cut with your choice of sides. Perfectly seasoned every time.',              'Meal Prep',   'Premium',      2),
          (4, 'Bulk Pack — 5 Meals',   70, '5 classic meals, mix and match proteins. Save $5 vs individual pricing.',                  'Bulk Orders', 'Best Value',   3),
          (5, 'Bulk Steak Pack — 5 Meals', 85, '5 steak preps, fresh all week. The move for serious meal preppers.',                  'Bulk Orders', NULL,           4);

        CREATE TABLE IF NOT EXISTS orders (
            id              TEXT    PRIMARY KEY,
            customer_name   TEXT    NOT NULL,
            customer_phone  TEXT    NOT NULL,
            customer_email  TEXT    DEFAULT '',
            pickup_time     TEXT    NOT NULL,
            notes           TEXT    DEFAULT '',
            items_json      TEXT    NOT NULL,   -- [{id, name, qty, unit_price}]
            subtotal        REAL    NOT NULL,
            status          TEXT    NOT NULL DEFAULT 'pending',
                -- pending | confirmed | ready | picked_up | cancelled
            stripe_session_id TEXT  DEFAULT NULL,
            payment_status  TEXT    NOT NULL DEFAULT 'unpaid',
                -- unpaid | paid | refunded
            created_at      TEXT    DEFAULT (datetime('now')),
            updated_at      TEXT    DEFAULT (datetime('now'))
        );
        """)
        db.commit()

# ── Utils ─────────────────────────────────────────────────────────────────────

def row_to_dict(row):
    return dict(row) if row else None

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT

def now_iso():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

# ── Vendor ────────────────────────────────────────────────────────────────────

@app.route("/api/vendor", methods=["GET"])
def get_vendor():
    db = get_db()
    v  = row_to_dict(db.execute("SELECT * FROM vendor WHERE id=1").fetchone())
    return jsonify(v)

@app.route("/api/vendor", methods=["PUT"])
def update_vendor():
    db   = get_db()
    data = request.get_json(force=True)
    allowed = ["name", "slug", "instagram", "phone", "location",
               "hours", "payment_methods", "accent_color", "theme",
               "logo_url", "hero_url"]
    sets = ", ".join(f"{k}=?" for k in allowed if k in data)
    vals = [data[k] for k in allowed if k in data]
    if not sets:
        return jsonify({"error": "Nothing to update"}), 400
    vals.append(now_iso())
    db.execute(f"UPDATE vendor SET {sets}, updated_at=? WHERE id=1", vals)
    db.commit()
    v = row_to_dict(db.execute("SELECT * FROM vendor WHERE id=1").fetchone())
    return jsonify(v)

@app.route("/api/vendor/status", methods=["GET"])
def get_status():
    db = get_db()
    row = db.execute("SELECT is_open, hours FROM vendor WHERE id=1").fetchone()
    return jsonify({"is_open": bool(row["is_open"]), "hours": row["hours"]})

@app.route("/api/vendor/status", methods=["PUT"])
def set_status():
    db   = get_db()
    data = request.get_json(force=True)
    is_open = int(bool(data.get("is_open", True)))
    db.execute("UPDATE vendor SET is_open=?, updated_at=? WHERE id=1",
               [is_open, now_iso()])
    db.commit()
    return jsonify({"is_open": bool(is_open)})

# ── Menu ──────────────────────────────────────────────────────────────────────

@app.route("/api/menu", methods=["GET"])
def get_menu():
    db    = get_db()
    items = db.execute(
        "SELECT * FROM menu_items ORDER BY sort_order ASC, id ASC"
    ).fetchall()
    return jsonify([row_to_dict(r) for r in items])

@app.route("/api/menu", methods=["POST"])
def create_menu_item():
    db   = get_db()
    data = request.get_json(force=True)
    required = ["name", "price"]
    for f in required:
        if f not in data:
            return jsonify({"error": f"Missing field: {f}"}), 400
    cur = db.execute(
        """INSERT INTO menu_items
           (name, price, description, category, tag, photo_url, is_available, sort_order)
           VALUES (?,?,?,?,?,?,?,?)""",
        [
            data["name"],
            float(data["price"]),
            data.get("description", ""),
            data.get("category", "Meal Prep"),
            data.get("tag"),
            data.get("photo_url"),
            int(data.get("is_available", True)),
            data.get("sort_order", 0),
        ]
    )
    db.commit()
    row = row_to_dict(db.execute("SELECT * FROM menu_items WHERE id=?", [cur.lastrowid]).fetchone())
    return jsonify(row), 201

@app.route("/api/menu/<int:item_id>", methods=["PUT"])
def update_menu_item(item_id):
    db   = get_db()
    data = request.get_json(force=True)
    allowed = ["name", "price", "description", "category", "tag",
               "photo_url", "is_available", "sort_order"]
    sets = ", ".join(f"{k}=?" for k in allowed if k in data)
    vals = [data[k] for k in allowed if k in data]
    if not sets:
        return jsonify({"error": "Nothing to update"}), 400
    vals += [now_iso(), item_id]
    db.execute(f"UPDATE menu_items SET {sets}, updated_at=? WHERE id=?", vals)
    db.commit()
    row = row_to_dict(db.execute("SELECT * FROM menu_items WHERE id=?", [item_id]).fetchone())
    if not row:
        return jsonify({"error": "Not found"}), 404
    return jsonify(row)

@app.route("/api/menu/<int:item_id>", methods=["DELETE"])
def delete_menu_item(item_id):
    db = get_db()
    db.execute("DELETE FROM menu_items WHERE id=?", [item_id])
    db.commit()
    return jsonify({"deleted": item_id})

# ── Checkout / Orders ─────────────────────────────────────────────────────────

@app.route("/api/checkout/initiate", methods=["POST"])
def checkout_initiate():
    """
    Validates the cart against live menu prices (server-side price authority).
    Returns an order summary with authoritative totals.

    When you add Stripe keys, swap the bottom section to create a
    stripe.checkout.Session and return the session URL.
    """
    db   = get_db()
    data = request.get_json(force=True)

    cart = data.get("items", [])     # [{id, qty}]
    if not cart:
        return jsonify({"error": "Cart is empty"}), 400

    line_items = []
    subtotal   = 0.0

    for ci in cart:
        item_id = int(ci["id"])
        qty     = int(ci["qty"])
        if qty < 1:
            continue
        row = db.execute(
            "SELECT * FROM menu_items WHERE id=? AND is_available=1", [item_id]
        ).fetchone()
        if not row:
            return jsonify({"error": f"Item {item_id} is unavailable or not found"}), 400
        unit = float(row["price"])
        line_items.append({
            "id":         row["id"],
            "name":       row["name"],
            "qty":        qty,
            "unit_price": unit,
            "line_total": round(unit * qty, 2),
        })
        subtotal += unit * qty

    subtotal = round(subtotal, 2)

    # ── Stripe integration placeholder ────────────────────────────────────────
    # import stripe
    # stripe.api_key = os.environ["STRIPE_SECRET_KEY"]
    # session = stripe.checkout.Session.create(
    #     payment_method_types=["card"],
    #     line_items=[
    #         {
    #             "price_data": {
    #                 "currency": "usd",
    #                 "unit_amount": int(li["unit_price"] * 100),
    #                 "product_data": {"name": li["name"]},
    #             },
    #             "quantity": li["qty"],
    #         }
    #         for li in line_items
    #     ],
    #     mode="payment",
    #     success_url="https://yourdomain.com/order-confirmed?session={CHECKOUT_SESSION_ID}",
    #     cancel_url="https://yourdomain.com/menu",
    # )
    # return jsonify({"stripe_url": session.url, "line_items": line_items, "subtotal": subtotal})
    # ─────────────────────────────────────────────────────────────────────────

    return jsonify({
        "line_items": line_items,
        "subtotal":   subtotal,
        "stripe_ready": False,   # flip to True once keys are added
        "message": "Cart validated. Add your Stripe keys to enable card payments.",
    })

@app.route("/api/orders", methods=["POST"])
def place_order():
    db   = get_db()
    data = request.get_json(force=True)

    required = ["customer_name", "customer_phone", "pickup_time", "items"]
    for f in required:
        if not data.get(f):
            return jsonify({"error": f"Missing field: {f}"}), 400

    # Re-price from DB (never trust client totals)
    cart       = data["items"]   # [{id, qty}]
    line_items = []
    subtotal   = 0.0

    for ci in cart:
        row = db.execute(
            "SELECT * FROM menu_items WHERE id=? AND is_available=1", [int(ci["id"])]
        ).fetchone()
        if not row:
            return jsonify({"error": f"Item {ci['id']} unavailable"}), 400
        qty  = int(ci["qty"])
        unit = float(row["price"])
        line_items.append({"id": row["id"], "name": row["name"],
                            "qty": qty, "unit_price": unit})
        subtotal += unit * qty

    order_id = str(uuid.uuid4())[:8].upper()  # short friendly ID

    db.execute(
        """INSERT INTO orders
           (id, customer_name, customer_phone, customer_email,
            pickup_time, notes, items_json, subtotal, status, payment_status)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        [
            order_id,
            data["customer_name"],
            data["customer_phone"],
            data.get("customer_email", ""),
            data["pickup_time"],
            data.get("notes", ""),
            json.dumps(line_items),
            round(subtotal, 2),
            "pending",
            "unpaid",
        ]
    )
    db.commit()

    return jsonify({
        "order_id": order_id,
        "status":   "pending",
        "subtotal": round(subtotal, 2),
        "line_items": line_items,
        "message": f"Order {order_id} placed! Wayne will confirm shortly.",
    }), 201

@app.route("/api/orders", methods=["GET"])
def list_orders():
    db = get_db()
    status = request.args.get("status")
    if status:
        rows = db.execute(
            "SELECT * FROM orders WHERE status=? ORDER BY created_at DESC", [status]
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM orders ORDER BY created_at DESC"
        ).fetchall()

    orders = []
    for r in rows:
        o = row_to_dict(r)
        o["items_json"] = json.loads(o["items_json"])
        orders.append(o)
    return jsonify(orders)

@app.route("/api/orders/<order_id>", methods=["GET"])
def get_order(order_id):
    db  = get_db()
    row = db.execute("SELECT * FROM orders WHERE id=?", [order_id]).fetchone()
    if not row:
        return jsonify({"error": "Order not found"}), 404
    o = row_to_dict(row)
    o["items_json"] = json.loads(o["items_json"])
    return jsonify(o)

@app.route("/api/orders/<order_id>/status", methods=["PUT"])
def update_order_status(order_id):
    db     = get_db()
    data   = request.get_json(force=True)
    status = data.get("status")
    valid  = {"pending", "confirmed", "ready", "picked_up", "cancelled"}
    if status not in valid:
        return jsonify({"error": f"status must be one of {sorted(valid)}"}), 400
    db.execute(
        "UPDATE orders SET status=?, updated_at=? WHERE id=?",
        [status, now_iso(), order_id]
    )
    db.commit()
    return jsonify({"order_id": order_id, "status": status})

# ── File uploads ──────────────────────────────────────────────────────────────

@app.route("/api/uploads", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file field"}), 400
    f = request.files["file"]
    if not f.filename or not allowed_file(f.filename):
        return jsonify({"error": "Invalid file type"}), 400
    ext      = f.filename.rsplit(".", 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    f.save(os.path.join(UPLOAD_DIR, filename))
    return jsonify({"url": f"/api/uploads/{filename}", "filename": filename}), 201

@app.route("/api/uploads/<filename>")
def serve_upload(filename):
    return send_from_directory(UPLOAD_DIR, filename)

# ── Static files ─────────────────────────────────────────────────────────────

@app.route("/")
def serve_index():
    return send_from_directory(BASE_DIR, "index.html")

@app.route("/<path:filename>")
def serve_static(filename):
    return send_from_directory(BASE_DIR, filename)

# ── Health check ──────────────────────────────────────────────────────────────

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Street Eatz Vendor API"})

# ── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    print("\n✅  Street Eatz backend running on http://localhost:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=True)
